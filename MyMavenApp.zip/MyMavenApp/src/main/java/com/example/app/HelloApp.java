package com.example.app;

public class HelloApp {
public static void main(String args[]) {
	System.out.println("Hello from Maven Project!");
}
}
 