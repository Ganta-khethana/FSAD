package com.example.freelancer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreelancerSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
