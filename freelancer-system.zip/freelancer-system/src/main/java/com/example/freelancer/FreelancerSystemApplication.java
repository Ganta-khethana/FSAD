package com.example.freelancer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreelancerSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreelancerSystemApplication.class, args);
	}

}
